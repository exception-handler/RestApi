package com.infy.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.infy.dao.EmployeeDaoImpl;
import com.infy.model.Employee;

@Path("service")
public class EmployeeService {

	EmployeeDaoImpl employee=new EmployeeDaoImpl();
	
	@Path("getAll")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getAllEmployee() {

		// retrieval logic
		return employee.getAllEmployee();
	}
	
	@Path("add")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String addProject(Employee emp) {

		// addition logic

		employee.addEmployee(emp);

		return "Record Added";
	}
	
	@Path("getSalary/{x}/{y}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getSalary(@PathParam("x")float x1,@PathParam("y")float x2)
	{
		
		return employee.getSalary(x1,x2);
	}
	
	@Path("getJsonById/{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getEmployeeById(@PathParam("id")int Id)
	{
		return employee.getEmployeeById(Id);
	}
	
	@Path("update")
	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes({MediaType.APPLICATION_JSON})
	public String updateEmployee(Employee emp1)
	{
		employee.updateEmployee(emp1);
		return "Record Updated";
	}


	@Path("updateName")
	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes({MediaType.APPLICATION_JSON})
	public String updateEmployeeName(Employee emp1)
	{
		employee.updateEmployeeName(emp1);
		return "Record Updated";
	}
	
	@Path("remove/{id}")
	@DELETE
	@Produces(MediaType.TEXT_PLAIN)
	public String deleteEmployee(@PathParam("id")int pId)
	{
		employee.deleteEmployee(pId);
		return "Record deleted";
	}
}
