package com.infy.dao;

import java.util.List;

import com.infy.model.Employee;

public interface EmployeeDao {
	List<Employee> getAllEmployee();
	void addEmployee(Employee emp);
	List<Employee> getSalary(float x, float y);
	List<Employee> getEmployeeById(int Id);
	void updateEmployeeName(Employee emp);
	void updateEmployee(Employee emp);
	void deleteEmployee(int id);
}
