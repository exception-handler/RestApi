package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;

import com.infy.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	
	Transaction transaction;
	Session session;

	public EmployeeDaoImpl() {
		AnnotationConfiguration configuration = new AnnotationConfiguration();
		configuration.configure();
		SessionFactory factory = configuration.buildSessionFactory();
		session = factory.openSession();
		//transaction = session.beginTransaction();
	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> empList = new ArrayList<>();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("from Employee");
		empList = query.list();
		t.commit();
		return empList;
	}

	@Override
	public void addEmployee(Employee emp) {
		System.out.println("Inside add proj---");
		Transaction t=session.beginTransaction();
		session.save(emp);
		t.commit();
	
		
	}

	@Override
	public List<Employee> getSalary(float x, float y) {
		/*List<Employee> empList = new ArrayList<>();
		List<Employee> empList1 = new ArrayList<>();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("from Employee");
		empList = query.list();
		for (int i = 0; i < empList.size(); i++) {
			if(empList.get(i).getSalary()>x && empList.get(i).getSalary()<y)
			{
				empList1.add(empList.get(i));
			}
		}
		return empList1;*/
		Transaction t=session.beginTransaction();
		List<Employee> empList = new ArrayList<>();
		Criteria criteria=session.createCriteria(Employee.class);
		empList=criteria.add(Restrictions.between("salary", x, y)).list();
		t.commit();
		return empList;
		
		
	}

	@Override
	public List<Employee> getEmployeeById(int Id) {
		Transaction t=session.beginTransaction();
		List<Employee> empList=new ArrayList<>();
		Criteria criteria=session.createCriteria(Employee.class);
		empList=criteria.add(Restrictions.eq("id", Id)).list();
		t.commit();
		return empList;
	}

	@Override
	public void updateEmployeeName(Employee emp) {
	/*	Transaction t=session.beginTransaction();
		List<Employee> empList=new ArrayList<>();
		Query query = session.createQuery("from Employee");
		empList = query.list();
		int id=emp.getEmployeeId();
		for (int i = 0; i < empList.size(); i++) {
			if(empList.get(i).getEmployeeId()==id)
			{
				empList.get(i).setName(emp.getName());;
				
			}//if ends
		}//for ends
		session.save(empList);
		t.commit();*/
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("update Employee set name=? where employeeId=?");
		query.setString(0, emp.getName());
		query.setInteger(1, emp.getEmployeeId());
		query.executeUpdate();
		t.commit();
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		/*Transaction t=session.beginTransaction();
		List<Employee> empList=new ArrayList<>();
		Query query = session.createQuery("from Employee");
		empList = query.list();
		int id=emp.getEmployeeId();
		System.out.println(id);
		for (int i = 0; i < empList.size(); i++) {
			if(empList.get(i).getEmployeeId()==id)
			{
				empList.get(i).setName(emp.getName());
				empList.get(i).setEmployeeId(emp.getEmployeeId());
				empList.get(i).setDesignation(emp.getDesignation());
				empList.get(i).setSalary(emp.getSalary());
				
				
			}//if ends
		}//for ends
		session.save(empList);
		t.commit();*/
		
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("update Employee set name=?,salary=?,designation=? where employeeId=?");
		
		query.setString(0, emp.getName());
	
		query.setFloat(1, emp.getSalary());
		query.setString(2, emp.getDesignation());
		query.setInteger(3, emp.getEmployeeId());
		query.executeUpdate();
		t.commit();
	}

	@Override
	public void deleteEmployee(int id) {
		/*Transaction t=session.beginTransaction();
		List<Employee> empList=new ArrayList<>();
		Query query = session.createQuery("from Employee");
		empList = query.list();
		for (int i = 0; i < empList.size(); i++) {
			if(empList.get(i).getEmployeeId()==id)
			{
				session.delete(empList.get(i));
			}//if ends
		}//for ends
*/		
		Transaction t=session.beginTransaction();
		Employee emp=(Employee) session.get(Employee.class, id);
		session.delete(emp);
		t.commit();
	}

}
